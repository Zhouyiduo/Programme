﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProIOPro
{
    public class SubProIOPip
    {
        public void Send(string value)
        {
        }

        // 这个函数是阻塞的
        public bool Receive()
        {
            return true;
        }
    }
}
